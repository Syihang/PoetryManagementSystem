-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: poetrydatabase
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `poetry`
--

DROP TABLE IF EXISTS `poetry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poetry` (
  `poetry_id` int NOT NULL AUTO_INCREMENT COMMENT '诗词编号',
  `title` varchar(20) NOT NULL DEFAULT '无题' COMMENT '标题',
  `author` varchar(20) NOT NULL DEFAULT '佚名' COMMENT '作者',
  `dynasty` char(10) DEFAULT NULL COMMENT '作者朝代',
  `star` int NOT NULL DEFAULT '0' COMMENT '收藏数',
  `type` char(10) NOT NULL DEFAULT '暂无归类' COMMENT '类别',
  `text` text NOT NULL COMMENT '诗词正文',
  PRIMARY KEY (`poetry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='诗词表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poetry`
--

LOCK TABLES `poetry` WRITE;
/*!40000 ALTER TABLE `poetry` DISABLE KEYS */;
INSERT INTO `poetry` VALUES (1,'静夜思','李白','唐代',1000,'唐诗','床前明月光，疑是地上霜。举头望明月，低头思故乡。'),(2,'水调歌头','苏轼','宋代',1500,'宋词','明月几时有？把酒问青天。\n不知天上宫阙，今夕是何年。'),(3,'登鹳雀楼','王之涣','唐代',1200,'唐诗','白日依山尽，黄河入海流。\n欲穷千里目，更上一层楼。'),(4,'春江花月夜','张若虚','唐代',0,'唐诗','春江潮水连海平，海上明月共潮生。\n滟滟随波千万里，何处春江无月明。\n江流宛转绕芳甸，月照花林皆似霰。\n空里流霜不觉飞，汀上白沙看不见。\n江天一色无纤尘，皎皎空中孤月轮。\n江畔何人初见月，江月何年初照人。\n人生代代无穷已，江月年年望相似。\n不知江月待何人，但见长江送流水。\n白云一片去悠悠，青枫浦上不胜愁。\n谁家今夜扁舟子，何处相思明月楼。\n可怜楼上月徘徊，应照离人妆镜台。\n玉户帘中卷不去，捣衣砧上拂还来。\n此时相望不相闻，愿逐月华流照君。\n鸿雁长飞光不度，鱼龙潜跃水成文。\n昨夜闲潭梦落花，可怜春半不还家。\n江水流春去欲尽，江潭落月复西斜。\n斜月沉沉藏海雾，碣石潇湘无限路。\n不知乘月几人归，落月摇情满江树。'),(6,'将进酒','李白','唐代',1400,'唐诗','君不见，黄河之水天上来，奔流到海不复回。\n君不见，高堂明镜悲白发，朝如青丝暮成雪。'),(7,'早发白帝城','李白','唐代',1300,'唐诗','朝辞白帝彩云间，千里江陵一日还。\n两岸猿声啼不住，轻舟已过万重山。'),(8,'相思','王维','唐代',1100,'唐诗','红豆生南国，春来发几枝。\n愿君多采撷，此物最相思。'),(9,'山居秋暝','王维','唐代',1050,'唐诗','空山新雨后，天气晚来秋。\n明月松间照，清泉石上流。'),(11,'春晓','孟浩然','唐代',850,'唐诗','春眠不觉晓，处处闻啼鸟。\n夜来风雨声，花落知多少。'),(12,'清明','杜牧','唐代',900,'唐诗','清明时节雨纷纷，路上行人欲断魂。\n借问酒家何处有，牧童遥指杏花村。'),(13,'秋夕','杜牧','唐代',950,'唐诗','银烛秋光冷画屏，轻罗小扇扑流萤。\n天阶夜色凉如水，卧看牵牛织女星。'),(14,'泊船瓜洲','王安石','宋代',920,'宋词','京口瓜洲一水间，钟山只隔数重山。\n春风又绿江南岸，明月何时照我还？'),(15,'雨霖铃','柳永','宋代',880,'宋词','寒蝉凄切，对长亭晚，骤雨初歇。\n都门帐饮无绪，留恋处，兰舟催发。'),(16,'蝶恋花','苏轼','宋代',1350,'宋词','花褪残红青杏小，燕子飞时，绿水人家绕。\n枝上柳绵吹又少，天涯何处无芳草！'),(17,'浣溪沙','秦观','宋代',950,'宋词','漠漠轻寒上小楼，晓阴无赖似穷秋。\n淡烟流水画屏幽。'),(18,'西江月','辛弃疾','宋代',1050,'宋词','明月别枝惊鹊，清风半夜鸣蝉。\n稻花香里说丰年，听取蛙声一片。'),(19,'青玉案','辛弃疾','宋代',1200,'宋词','东风夜放花千树。更吹落、星如雨。\n宝马雕车香满路。凤箫声动，玉壶光转，一夜鱼龙舞。'),(20,'破阵子','晏殊','宋代',940,'宋词','燕子来时新社，梨花落后清明。\n池上碧苔三四点，叶底黄鹂一两声。'),(21,'声声慢','李清照','宋代',1600,'宋词','寻寻觅觅，冷冷清清，凄凄惨惨戚戚。\n乍暖还寒时候，最难将息。'),(22,'一剪梅','李清照','宋代',1250,'宋词','红藕香残玉簟秋，轻解罗裳，独上兰舟。\n云中谁寄锦书来？雁字回时，月满西楼。'),(24,'蝶恋花','欧阳修','宋代',850,'宋词','庭院深深深几许。\n杨柳堆烟，帘幕无重数。\n玉勒雕鞍游冶处，楼高不见章台路。\n雨横风狂三月暮。门掩黄昏，无计留春住。\n泪眼问花花不语，乱红飞过秋千去。'),(25,'永遇乐','辛弃疾','宋代',1150,'宋词','千古江山，英雄无觅，孙仲谋处。\n舞榭歌台，风流总被，雨打风吹去。'),(26,'浪淘沙','刘禹锡','唐代',800,'唐诗','九曲黄河万里沙，浪淘风簸自天涯。\n如今直上银河去，同到牵牛织女家。');
/*!40000 ALTER TABLE `poetry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-27 13:31:08
